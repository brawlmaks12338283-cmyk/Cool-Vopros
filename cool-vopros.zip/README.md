# Cool Vopros - Starter Project

Готовый минимальный шаблон сайта **Cool Vopros** (Next.js + TailwindCSS + Firebase).
Этот архив содержит базовую структуру; после развёртывания на Vercel нужно будет настроить Firebase и переменные окружения.

## Что сделано
- Главная страница со списком вопросов (заглушка)
- Страницы для входа (Google/GitHub) — настройка через Firebase Auth
- Админ-панель: `/admin` (доступ контролируется по EMAIL_ADMIN в env)
- TailwindCSS включён как зависимость (примеры стилей в коде)
- README с инструкциями по деплою на Vercel

## Как быстро запустить локально
1. Установи зависимости:
   ```bash
   npm install
   ```
2. Добавь переменные окружения в `.env.local` (пример ниже).
3. Запусти `npm run dev`.

## Переменные окружения (пример `.env.local`)
```
NEXT_PUBLIC_FIREBASE_API_KEY=your_api_key
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=your_auth_domain
NEXT_PUBLIC_FIREBASE_PROJECT_ID=your_project_id
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=your_storage_bucket
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=your_msg_sender_id
NEXT_PUBLIC_FIREBASE_APP_ID=your_app_id

# Админ email (тебя сделали админом)
NEXT_PUBLIC_ADMIN_EMAIL=brawlmaks12338283@gmail.com
```

## Деплой на Vercel
1. Зарегистрируйся/войди на vercel.com.
2. Создай новый проект → Import → Upload → выбери этот архив.
3. Укажи переменные окружения в настройках проекта на Vercel.
4. Разверни — сайт появится по адресу `https://coolvopros.vercel.app` (если домен свободен).